# 🌸 Nestora — Where Generations Grow Together

A premium, emotionally engaging, fully responsive website for an intergenerational wellness and care community.

## ✨ Features

- **10 fully-designed sections**: Hero, About, Why Nestora, Services, Daily Life, Safety, Testimonials, Gallery, CTA, Footer
- **Faceless pastel flat-vector illustrations** — all custom SVG, no stock photos
- **Framer Motion animations** — scroll reveals, floating elements, hover effects, gradient blobs
- **Glassmorphism panels** throughout
- **Fully responsive** — mobile, tablet, and desktop
- **Smooth scrolling** and premium transitions
- **Pastel color palette** — rose, cream, mint, lavender, peach, powder blue

## 🛠️ Tech Stack

- **React 18** + **Vite**
- **Tailwind CSS 3** — custom palette, animations, utilities
- **Framer Motion 11** — scroll-triggered animations, floating effects
- **Lucide React** — icon library
- **Google Fonts** — Poppins, Nunito, DM Sans

## 🚀 Getting Started

### 1. Clone / Download

```bash
git clone https://github.com/yourusername/nestora.git
cd nestora
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Run Development Server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### 4. Build for Production

```bash
npm run build
```

The built files will be in the `dist/` folder.

### 5. Preview Production Build

```bash
npm run preview
```

## 📁 Project Structure

```
nestora/
├── public/
├── src/
│   ├── components/
│   │   ├── Illustrations.jsx   ← All custom SVG illustrations
│   │   ├── Navbar.jsx          ← Sticky animated navbar
│   │   ├── Hero.jsx            ← Hero with floating animations
│   │   ├── About.jsx           ← Mission & pillars
│   │   ├── WhyNestora.jsx      ← Feature cards grid
│   │   ├── Services.jsx        ← Two-column services
│   │   ├── DailyLife.jsx       ← Masonry activity cards
│   │   ├── Safety.jsx          ← Safety & wellness
│   │   ├── Testimonials.jsx    ← Reviews with mobile carousel
│   │   ├── Gallery.jsx         ← Illustration gallery grid
│   │   ├── CTA.jsx             ← Call-to-action
│   │   └── Footer.jsx          ← Full footer with newsletter
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css               ← Tailwind + custom utilities
├── index.html
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── package.json
```

## 🌐 Deploying to GitHub Pages

1. Install gh-pages:
```bash
npm install --save-dev gh-pages
```

2. Add to `package.json`:
```json
"homepage": "https://yourusername.github.io/nestora",
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d dist"
}
```

3. Update `vite.config.js`:
```js
export default defineConfig({
  plugins: [react()],
  base: '/nestora/',
})
```

4. Deploy:
```bash
npm run deploy
```

## 🌐 Deploying to Vercel (Recommended)

1. Push to GitHub
2. Import project at [vercel.com](https://vercel.com)
3. Vercel auto-detects Vite — just click Deploy ✨

## 🎨 Customization

### Colors
Edit `tailwind.config.js` → `theme.extend.colors`

### Contact Info
Update email/phone in:
- `src/components/CTA.jsx` (mailto/tel links)
- `src/components/Footer.jsx` (contact section)

### Illustrations
All illustrations are in `src/components/Illustrations.jsx` as pure SVG React components — fully editable.

### Fonts
Change in `index.html` (Google Fonts link) and `tailwind.config.js` (`fontFamily`)

## 📄 License

MIT — free to use for your Nestora project.

---

Built with 💛 for every generation.
