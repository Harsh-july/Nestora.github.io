import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import WhyNestora from './components/WhyNestora'
import Services from './components/Services'
import DailyLife from './components/DailyLife'
import Safety from './components/Safety'
import Testimonials from './components/Testimonials'
import Gallery from './components/Gallery'
import CTA from './components/CTA'
import Footer from './components/Footer'

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <About />
        <WhyNestora />
        <Services />
        <DailyLife />
        <Safety />
        <Testimonials />
        <Gallery />
        <CTA />
      </main>
      <Footer />
    </div>
  )
}
