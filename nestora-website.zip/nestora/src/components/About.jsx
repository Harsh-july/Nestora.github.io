import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { Heart, Users, Leaf, Star } from 'lucide-react'
import { AboutIllustration } from './Illustrations'

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
}

const pillars = [
  {
    icon: <Heart className="w-5 h-5" />,
    color: 'from-rose-100 to-pink-100 text-rose-400',
    title: 'Healing Loneliness',
    desc: 'Both generations find genuine human connection, reducing isolation for the elderly and nurturing social warmth in children.',
  },
  {
    icon: <Leaf className="w-5 h-5" />,
    color: 'from-emerald-100 to-mint-light text-emerald-500',
    title: 'Meaningful Aging',
    desc: 'Elders find new purpose and vitality as mentors, storytellers, and caregivers — rediscovering the joy of being needed.',
  },
  {
    icon: <Star className="w-5 h-5" />,
    color: 'from-amber-100 to-yellow-100 text-amber-500',
    title: 'Emotional Intelligence',
    desc: 'Children raised with patience and wisdom from elders develop deeper empathy, resilience, and emotional understanding.',
  },
  {
    icon: <Users className="w-5 h-5" />,
    color: 'from-violet-100 to-lavender-light text-violet-400',
    title: 'Stronger Community',
    desc: 'We rebuild the intergenerational bonds that modern life has frayed, creating a village within our walls.',
  },
]

export default function About() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="about" className="py-24 lg:py-32 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className="grid lg:grid-cols-2 gap-16 xl:gap-24 items-center">
          {/* Illustration */}
          <motion.div
            initial={{ opacity: 0, x: -60, scale: 0.92 }}
            animate={isInView ? { opacity: 1, x: 0, scale: 1 } : {}}
            transition={{ duration: 0.9, ease: 'easeOut' }}
            className="relative order-2 lg:order-1"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-mint-pastel/40 via-cream to-lavender-pastel/30 rounded-[48px] blur-2xl scale-90" />
            <div className="relative glass rounded-[40px] p-8 shadow-soft">
              <AboutIllustration />
            </div>
            {/* Decorative badge */}
            <motion.div
              animate={{ rotate: [0, 5, 0, -5, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -bottom-6 -right-4 bg-gradient-to-br from-amber-200 to-orange-200 rounded-3xl px-5 py-4 shadow-soft text-center"
            >
              <div className="font-display font-extrabold text-2xl text-orange-700">10+</div>
              <div className="font-body text-xs text-orange-600 mt-0.5">Years of Joy</div>
            </motion.div>
          </motion.div>

          {/* Content */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate={isInView ? 'visible' : 'hidden'}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="order-1 lg:order-2"
          >
            <div className="inline-flex items-center gap-2 bg-rose-50 border border-rose-100 px-4 py-2 rounded-full mb-6">
              <Heart className="w-4 h-4 text-rose-400 fill-rose-300" />
              <span className="font-body text-sm text-rose-500 font-medium">Our Mission</span>
            </div>

            <h2 className="font-display font-extrabold text-4xl lg:text-5xl text-[#3D2C2C] leading-tight mb-6">
              More Than Care —{' '}
              <span className="text-gradient-warm">We Build</span>{' '}
              Connection
            </h2>

            <p className="font-body text-lg text-[#6B5B5B] leading-relaxed mb-6">
              In a world where the elderly sit in silence and children grow up without the wisdom of age, Nestora reimagines what community can look like.
            </p>
            <p className="font-body text-base text-[#8B7B7B] leading-relaxed mb-10">
              We believe that a child who spends time with grandparents grows with patience, empathy, and emotional depth. And an elder who spends time with children rediscovers their spark of joy, laughter, and purpose.
            </p>

            <div className="grid sm:grid-cols-2 gap-4">
              {pillars.map((p, i) => (
                <motion.div
                  key={p.title}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.4 + i * 0.1, duration: 0.6 }}
                  className="group p-4 rounded-2xl bg-[#FFF8F0] hover:bg-white hover:shadow-soft transition-all duration-300 border border-transparent hover:border-rose-50"
                >
                  <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${p.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                    {p.icon}
                  </div>
                  <h4 className="font-display font-bold text-sm text-[#3D2C2C] mb-1">{p.title}</h4>
                  <p className="font-body text-xs text-[#9B8B8B] leading-relaxed">{p.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
