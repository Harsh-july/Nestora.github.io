import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { Heart, ArrowRight, Sparkles } from 'lucide-react'

export default function CTA() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="contact" className="py-24 lg:py-32 bg-[#FFF8F0] overflow-hidden" ref={ref}>
      <div className="max-w-5xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
          transition={{ duration: 0.9, ease: 'easeOut' }}
          className="relative rounded-[48px] overflow-hidden bg-gradient-to-br from-rose-200 via-pink-100 to-peach-pastel p-12 lg:p-20 text-center shadow-soft"
        >
          {/* Background blobs */}
          <motion.div
            animate={{ scale: [1, 1.2, 1], rotate: [0, 10, 0] }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-0 left-0 w-64 h-64 rounded-full bg-white/30 blur-3xl -translate-x-1/2 -translate-y-1/2"
          />
          <motion.div
            animate={{ scale: [1.1, 1, 1.1], rotate: [0, -10, 0] }}
            transition={{ duration: 7, delay: 2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute bottom-0 right-0 w-80 h-80 rounded-full bg-white/20 blur-3xl translate-x-1/4 translate-y-1/4"
          />
          <motion.div
            animate={{ scale: [1, 1.15, 1] }}
            transition={{ duration: 6, delay: 1, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-1/2 left-1/2 w-48 h-48 rounded-full bg-lavender-pastel/30 blur-3xl -translate-x-1/2 -translate-y-1/2"
          />

          {/* Floating hearts */}
          {[
            { top: '10%', left: '5%', size: 20, delay: 0 },
            { top: '20%', right: '8%', size: 16, delay: 1 },
            { bottom: '15%', left: '10%', size: 14, delay: 2 },
            { bottom: '10%', right: '6%', size: 22, delay: 1.5 },
            { top: '50%', left: '2%', size: 12, delay: 3 },
            { top: '40%', right: '3%', size: 18, delay: 0.5 },
          ].map((h, i) => (
            <motion.div
              key={i}
              animate={{ y: [-10, 10, -10], rotate: [-8, 8, -8] }}
              transition={{ duration: 4 + i * 0.5, delay: h.delay, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute pointer-events-none"
              style={{ top: h.top, bottom: h.bottom, left: h.left, right: h.right }}
            >
              <Heart
                style={{ width: h.size, height: h.size }}
                className="text-white fill-white opacity-60"
              />
            </motion.div>
          ))}

          {/* Content */}
          <div className="relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 }}
              className="inline-flex items-center gap-2 bg-white/40 backdrop-blur px-4 py-2 rounded-full mb-8"
            >
              <Sparkles className="w-4 h-4 text-rose-500" />
              <span className="font-body text-sm text-rose-600 font-medium">Begin the Journey</span>
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.4 }}
              className="font-display font-extrabold text-4xl lg:text-6xl text-[#3D2C2C] leading-tight mb-6"
            >
              Because Every Generation{' '}
              <br className="hidden lg:block" />
              <span className="text-rose-500">Deserves Connection</span>
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.5 }}
              className="font-body text-lg lg:text-xl text-[#6B5B5B] max-w-2xl mx-auto mb-10 leading-relaxed"
            >
              Join a community where children grow with warmth and elderly people rediscover joy, purpose, and belonging. Your family's most meaningful chapter starts here.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <motion.a
                href="mailto:hello@nestora.in"
                whileHover={{ scale: 1.06, boxShadow: '0 12px 40px rgba(0,0,0,0.15)' }}
                whileTap={{ scale: 0.97 }}
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-[#3D2C2C] text-white font-display font-bold text-base shadow-soft"
              >
                <Heart className="w-4 h-4 fill-white" />
                Schedule a Visit
              </motion.a>
              <motion.a
                href="tel:+919999999999"
                whileHover={{ scale: 1.06 }}
                whileTap={{ scale: 0.97 }}
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-white/60 backdrop-blur border border-white text-[#3D2C2C] font-display font-bold text-base shadow-softer hover:bg-white/80 transition-colors"
              >
                Join Our Community
                <ArrowRight className="w-4 h-4" />
              </motion.a>
            </motion.div>

            {/* Small trust row */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.8 }}
              className="flex items-center justify-center gap-6 mt-10 text-[#6B5B5B]"
            >
              {['No commitment required', 'Free first visit', 'Open 7 days'].map((t) => (
                <div key={t} className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                  <span className="font-body text-xs">{t}</span>
                </div>
              ))}
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
