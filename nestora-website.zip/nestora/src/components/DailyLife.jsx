import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { Palette, Leaf, BookOpen, Gamepad2, Utensils } from 'lucide-react'
import {
  StorytellingIllustration,
  GardeningIllustration,
  DiningIllustration,
  PaintingIllustration,
} from './Illustrations'

const activities = [
  {
    icon: <Palette className="w-5 h-5" />,
    title: 'Painting Together',
    desc: 'Elderly artists guide little hands to create beautiful art — creativity has no age.',
    illustration: <PaintingIllustration />,
    bg: 'from-violet-50 to-lavender-light',
    badge: 'bg-violet-100 text-violet-500',
    span: 'lg:col-span-1',
  },
  {
    icon: <Leaf className="w-5 h-5" />,
    title: 'Garden Friends',
    desc: 'Tiny fingers and weathered hands plant seeds of friendship in our community garden.',
    illustration: <GardeningIllustration />,
    bg: 'from-emerald-50 to-mint-light',
    badge: 'bg-emerald-100 text-emerald-600',
    span: 'lg:col-span-1',
  },
  {
    icon: <BookOpen className="w-5 h-5" />,
    title: 'Story Time Magic',
    desc: 'Every afternoon, our elders weave tales of wonder that spark imagination in every little listener.',
    illustration: <StorytellingIllustration />,
    bg: 'from-amber-50 to-yellow-50',
    badge: 'bg-amber-100 text-amber-600',
    span: 'lg:col-span-2',
  },
  {
    icon: <Utensils className="w-5 h-5" />,
    title: 'Sharing Meals',
    desc: 'Shared tables create shared memories. Every meal is a celebration of togetherness.',
    illustration: <DiningIllustration />,
    bg: 'from-rose-50 to-peach-light',
    badge: 'bg-rose-100 text-rose-500',
    span: 'lg:col-span-2',
  },
  {
    icon: <Gamepad2 className="w-5 h-5" />,
    title: 'Games & Laughter',
    desc: 'Board games, puzzles, and outdoor play that bring generations together in pure joy.',
    illustration: null,
    bg: 'from-blue-50 to-powder-light',
    badge: 'bg-blue-100 text-blue-500',
    span: 'lg:col-span-1',
    emoji: '🎲',
  },
]

export default function DailyLife() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="daily-life" className="py-24 lg:py-32 bg-[#FFF8F0] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-100 px-4 py-2 rounded-full mb-6">
            <span className="text-amber-500 text-sm">✨</span>
            <span className="font-body text-sm text-amber-600 font-medium">A Day at Nestora</span>
          </div>
          <h2 className="font-display font-extrabold text-4xl lg:text-5xl text-[#3D2C2C] mb-5">
            Life Here Is{' '}
            <span className="text-gradient-warm">Beautiful</span>
          </h2>
          <p className="font-body text-lg text-[#6B5B5B] max-w-2xl mx-auto">
            Every moment at Nestora is crafted with intention — creating memories that last a lifetime for both generations.
          </p>
        </motion.div>

        {/* Masonry Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {activities.map((a, i) => (
            <motion.div
              key={a.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: i * 0.1 }}
              whileHover={{ y: -6 }}
              className={`${a.span} rounded-3xl bg-gradient-to-br ${a.bg} p-6 border border-white shadow-softer group transition-all duration-300 hover:shadow-soft overflow-hidden relative`}
            >
              {/* Floating bg shape */}
              <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white/30 group-hover:scale-125 transition-transform duration-500" />
              
              <div className="relative">
                <div className={`inline-flex items-center gap-2 ${a.badge} px-3 py-1.5 rounded-full text-xs font-display font-semibold mb-4`}>
                  {a.icon}
                  {a.title}
                </div>

                <p className="font-body text-sm text-[#6B5B5B] leading-relaxed mb-5">{a.desc}</p>

                {a.illustration ? (
                  <div className="w-full h-48 lg:h-56">
                    {a.illustration}
                  </div>
                ) : (
                  <div className="w-full h-32 flex items-center justify-center">
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] }}
                      transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                      className="text-7xl"
                    >
                      {a.emoji}
                    </motion.div>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
