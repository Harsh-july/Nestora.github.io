import { motion } from 'framer-motion'
import { Heart, Instagram, Facebook, Twitter, Youtube, Mail, Phone, MapPin, ArrowRight } from 'lucide-react'

const footerLinks = {
  'Quick Links': ['About Us', 'Our Services', 'Daily Life', 'Safety & Wellness', 'Gallery', 'Join as Elder'],
  'For Families': ['Book a Visit', 'Daycare Programs', 'Parent Portal', 'Testimonials', 'FAQs', 'Contact Us'],
  'Support': ['Privacy Policy', 'Terms of Service', 'Accessibility', 'Careers', 'Blog', 'Press'],
}

export default function Footer() {
  return (
    <footer className="bg-[#3D2C2C] text-white overflow-hidden relative">
      {/* Top wave */}
      <div className="absolute top-0 left-0 right-0 h-16 pointer-events-none">
        <svg viewBox="0 0 1440 64" className="w-full h-full" preserveAspectRatio="none">
          <path d="M0,0 C360,64 1080,0 1440,48 L1440,0 Z" fill="#FFF8F0" />
        </svg>
      </div>

      {/* Background blobs */}
      <div className="absolute top-20 left-0 w-64 h-64 rounded-full bg-rose-900/20 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 rounded-full bg-violet-900/20 blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-24 pb-12">
        <div className="grid lg:grid-cols-5 gap-12 mb-16">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-rose-300 to-orange-200 flex items-center justify-center">
                <Heart className="w-5 h-5 text-white fill-white" />
              </div>
              <span className="font-display font-extrabold text-2xl text-white">Nestora</span>
            </div>
            <p className="font-body text-sm text-white/60 leading-relaxed mb-6 max-w-xs">
              Where Generations Grow Together. A warm intergenerational community where children and elderly find purpose, companionship, and joy.
            </p>

            {/* Contact */}
            <div className="space-y-3 mb-8">
              {[
                { icon: <MapPin className="w-4 h-4" />, text: 'New Delhi, India' },
                { icon: <Phone className="w-4 h-4" />, text: '+91 99999 99999' },
                { icon: <Mail className="w-4 h-4" />, text: 'hello@nestora.in' },
              ].map((c) => (
                <div key={c.text} className="flex items-center gap-2 text-white/60 hover:text-white/90 transition-colors">
                  <span className="text-rose-300">{c.icon}</span>
                  <span className="font-body text-sm">{c.text}</span>
                </div>
              ))}
            </div>

            {/* Social icons */}
            <div className="flex gap-3">
              {[
                { icon: <Instagram className="w-4 h-4" />, label: 'Instagram' },
                { icon: <Facebook className="w-4 h-4" />, label: 'Facebook' },
                { icon: <Twitter className="w-4 h-4" />, label: 'Twitter' },
                { icon: <Youtube className="w-4 h-4" />, label: 'YouTube' },
              ].map((s) => (
                <motion.a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  whileHover={{ scale: 1.15, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-9 h-9 rounded-xl bg-white/10 hover:bg-rose-400/40 flex items-center justify-center text-white/70 hover:text-white transition-all duration-200"
                >
                  {s.icon}
                </motion.a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([heading, links]) => (
            <div key={heading}>
              <h4 className="font-display font-bold text-sm text-white mb-4">{heading}</h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="font-body text-sm text-white/55 hover:text-white/90 transition-colors flex items-center gap-1 group">
                      <span className="w-0 overflow-hidden group-hover:w-3 transition-all duration-200">
                        <ArrowRight className="w-3 h-3" />
                      </span>
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter */}
        <div className="rounded-2xl bg-white/5 border border-white/10 p-6 mb-12 flex flex-col md:flex-row items-center gap-6">
          <div className="flex-1">
            <h4 className="font-display font-bold text-base text-white mb-1">Stay connected with Nestora</h4>
            <p className="font-body text-sm text-white/55">Get heartwarming stories, updates, and community news.</p>
          </div>
          <div className="flex gap-3 w-full md:w-auto">
            <input
              type="email"
              placeholder="your@email.com"
              className="flex-1 md:w-64 px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/40 font-body text-sm focus:outline-none focus:border-rose-300 transition-colors"
            />
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              className="px-5 py-3 rounded-xl bg-gradient-to-r from-rose-300 to-orange-200 text-white font-display font-bold text-sm shadow-soft"
            >
              Subscribe
            </motion.button>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-8 border-t border-white/10">
          <p className="font-body text-xs text-white/40">
            © 2025 Nestora. All rights reserved. Made with{' '}
            <Heart className="w-3 h-3 inline text-rose-400 fill-rose-400" />{' '}
            for every generation.
          </p>
          <div className="flex gap-6">
            {['Privacy', 'Terms', 'Cookies'].map((l) => (
              <a key={l} href="#" className="font-body text-xs text-white/40 hover:text-white/70 transition-colors">
                {l}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
