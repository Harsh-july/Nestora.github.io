import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import {
  HeroIllustration,
  AboutIllustration,
  StorytellingIllustration,
  GardeningIllustration,
  DiningIllustration,
  PaintingIllustration,
} from './Illustrations'

const galleryItems = [
  {
    title: 'A Hug That Says It All',
    tag: '💛 Bond',
    illustration: <HeroIllustration />,
    bg: 'from-rose-50 to-peach-light',
    span: 'row-span-1',
  },
  {
    title: 'Storytime Magic',
    tag: '📚 Learning',
    illustration: <StorytellingIllustration />,
    bg: 'from-amber-50 to-yellow-50',
    span: 'row-span-2',
  },
  {
    title: 'Growing Together',
    tag: '🌱 Garden',
    illustration: <GardeningIllustration />,
    bg: 'from-emerald-50 to-mint-light',
    span: 'row-span-1',
  },
  {
    title: 'Reading Together',
    tag: '💜 Wisdom',
    illustration: <AboutIllustration />,
    bg: 'from-violet-50 to-lavender-light',
    span: 'row-span-1',
  },
  {
    title: 'Sharing a Meal',
    tag: '🍽️ Together',
    illustration: <DiningIllustration />,
    bg: 'from-orange-50 to-peach-light',
    span: 'row-span-1',
  },
  {
    title: 'Art Lessons',
    tag: '🎨 Creative',
    illustration: <PaintingIllustration />,
    bg: 'from-blue-50 to-powder-light',
    span: 'row-span-1',
  },
]

export default function Gallery() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="gallery" className="py-24 lg:py-32 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-rose-50 border border-rose-100 px-4 py-2 rounded-full mb-6">
            <span className="text-rose-400 text-sm">🎨</span>
            <span className="font-body text-sm text-rose-500 font-medium">Moments of Joy</span>
          </div>
          <h2 className="font-display font-extrabold text-4xl lg:text-5xl text-[#3D2C2C] mb-5">
            A Glimpse Into Our{' '}
            <span className="text-gradient-warm">World</span>
          </h2>
          <p className="font-body text-lg text-[#6B5B5B] max-w-2xl mx-auto">
            Every picture here represents a real moment of human connection — the kind of moments that Nestora creates every single day.
          </p>
        </motion.div>

        {/* Masonry grid */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6 auto-rows-64">
          {galleryItems.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: i * 0.1, duration: 0.7 }}
              whileHover={{ scale: 1.02, zIndex: 10 }}
              className={`${item.span} ${item.bg} bg-gradient-to-br rounded-3xl overflow-hidden relative shadow-softer hover:shadow-soft transition-all duration-300 border border-white group`}
            >
              {/* Tag */}
              <div className="absolute top-4 left-4 z-10 glass px-3 py-1 rounded-full text-xs font-body font-medium text-[#6B5B5B] shadow-softer">
                {item.tag}
              </div>

              {/* Illustration */}
              <div className="w-full h-full p-4 pt-12 flex items-end">
                <div className="w-full">
                  {item.illustration}
                </div>
              </div>

              {/* Overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-3xl" />
              <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <p className="font-display font-bold text-sm text-[#3D2C2C] glass px-3 py-2 rounded-xl inline-block shadow-softer">{item.title}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
