import { motion } from 'framer-motion'
import { Heart, ArrowRight, Sparkles } from 'lucide-react'
import { HeroIllustration } from './Illustrations'

const FloatingHeart = ({ style, delay = 0 }) => (
  <motion.div
    animate={{ y: [-12, 12, -12], rotate: [-5, 5, -5] }}
    transition={{ duration: 4 + Math.random() * 2, delay, repeat: Infinity, ease: 'easeInOut' }}
    style={style}
    className="absolute pointer-events-none"
  >
    <Heart className="text-rose-300 fill-rose-200" style={{ width: style.size || 20, height: style.size || 20 }} />
  </motion.div>
)

const Blob = ({ className, color, delay = 0 }) => (
  <motion.div
    animate={{ scale: [1, 1.1, 0.95, 1], x: [0, 20, -10, 0], y: [0, -15, 10, 0] }}
    transition={{ duration: 8, delay, repeat: Infinity, ease: 'easeInOut' }}
    className={`absolute rounded-full blur-3xl opacity-40 ${className} ${color}`}
  />
)

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-[#FFF8F0]" id="home">
      {/* Gradient blobs */}
      <Blob className="w-96 h-96 -top-20 -left-20" color="bg-pink-pastel" delay={0} />
      <Blob className="w-80 h-80 top-20 right-10" color="bg-powder-pastel" delay={2} />
      <Blob className="w-72 h-72 bottom-10 left-1/3" color="bg-mint-pastel" delay={4} />
      <Blob className="w-64 h-64 bottom-0 right-1/4" color="bg-lavender-pastel" delay={1} />

      {/* Floating hearts */}
      <FloatingHeart style={{ top: '20%', left: '8%', size: 16 }} delay={0} />
      <FloatingHeart style={{ top: '35%', left: '12%', size: 24 }} delay={1.5} />
      <FloatingHeart style={{ top: '60%', left: '5%', size: 14 }} delay={3} />
      <FloatingHeart style={{ top: '15%', right: '8%', size: 20 }} delay={2} />
      <FloatingHeart style={{ top: '50%', right: '5%', size: 28 }} delay={0.5} />
      <FloatingHeart style={{ bottom: '25%', right: '12%', size: 16 }} delay={4} />

      {/* Floating dots */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          animate={{ y: [0, -20, 0], opacity: [0.3, 0.7, 0.3] }}
          transition={{ duration: 3 + i * 0.5, delay: i * 0.3, repeat: Infinity }}
          className="absolute rounded-full"
          style={{
            width: 6 + (i % 4) * 4,
            height: 6 + (i % 4) * 4,
            left: `${5 + i * 8}%`,
            top: `${15 + (i % 5) * 15}%`,
            background: ['#F9C6D3','#C8EDD9','#DDD6F3','#C5DFF8','#FDDCBC'][i % 5],
          }}
        />
      ))}

      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-28 pb-16 grid lg:grid-cols-2 gap-16 items-center">
        {/* Text Content */}
        <motion.div
          initial={{ opacity: 0, x: -60 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9, ease: 'easeOut', delay: 0.2 }}
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full shadow-softer mb-8"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="font-body text-sm text-[#6B5B5B] font-medium">Intergenerational Wellness Community</span>
          </motion.div>

          <h1 className="font-display font-extrabold text-5xl lg:text-6xl xl:text-7xl leading-tight text-[#3D2C2C] mb-6">
            Where{' '}
            <span className="text-gradient-warm">Generations</span>
            <br />
            Grow Together
          </h1>

          <p className="font-body text-lg lg:text-xl text-[#6B5B5B] leading-relaxed mb-10 max-w-xl">
            Nestora creates a warm and joyful space where children and elderly people build meaningful bonds through care, learning, companionship, and love.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <motion.a
              href="#contact"
              whileHover={{ scale: 1.05, boxShadow: '0 8px 32px rgba(249,114,114,0.3)' }}
              whileTap={{ scale: 0.97 }}
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-rose-300 to-orange-200 text-white font-display font-bold text-base shadow-soft"
            >
              <Heart className="w-4 h-4 fill-white" />
              Book a Visit
            </motion.a>
            <motion.a
              href="#about"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl glass border border-rose-100 text-[#6B5B5B] font-display font-semibold text-base shadow-softer hover:border-rose-200 transition-colors"
            >
              Explore Our Community
              <ArrowRight className="w-4 h-4" />
            </motion.a>
          </div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="flex gap-8 mt-12"
          >
            {[
              { num: '200+', label: 'Happy Families' },
              { num: '50+', label: 'Elder Companions' },
              { num: '5★', label: 'Parent Rating' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="font-display font-extrabold text-2xl text-gradient-warm">{stat.num}</div>
                <div className="font-body text-xs text-[#9B8B8B] mt-1">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </motion.div>

        {/* Illustration */}
        <motion.div
          initial={{ opacity: 0, x: 60, scale: 0.9 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          transition={{ duration: 1, ease: 'easeOut', delay: 0.3 }}
          className="relative flex items-center justify-center"
        >
          {/* Glow ring */}
          <div className="absolute inset-0 bg-gradient-to-br from-pink-pastel/30 via-cream to-mint-pastel/30 rounded-[48px] blur-2xl" />
          
          <motion.div
            animate={{ y: [-8, 8, -8] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
            className="relative w-full max-w-lg"
          >
            <div className="glass rounded-[40px] p-6 shadow-soft">
              <HeroIllustration />
            </div>
          </motion.div>

          {/* Floating mini cards */}
          <motion.div
            animate={{ y: [-5, 5, -5] }}
            transition={{ duration: 4, delay: 1, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -left-4 top-1/4 glass rounded-2xl px-4 py-3 shadow-soft"
          >
            <div className="flex items-center gap-2">
              <span className="text-xl">🌻</span>
              <div>
                <p className="font-display font-bold text-xs text-[#3D2C2C]">Today's Activity</p>
                <p className="font-body text-xs text-[#9B8B8B]">Storytelling Circle</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            animate={{ y: [5, -5, 5] }}
            transition={{ duration: 5, delay: 2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -right-4 bottom-1/3 glass rounded-2xl px-4 py-3 shadow-soft"
          >
            <div className="flex items-center gap-2">
              <span className="text-xl">💚</span>
              <div>
                <p className="font-display font-bold text-xs text-[#3D2C2C]">Wellness Score</p>
                <p className="font-body text-xs text-[#9B8B8B]">Excellent Today</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none">
        <svg viewBox="0 0 1440 96" className="w-full h-full" preserveAspectRatio="none">
          <path d="M0,64 C360,100 1080,20 1440,64 L1440,96 L0,96 Z" fill="#FFF0F5" opacity="0.6" />
          <path d="M0,80 C480,40 960,100 1440,70 L1440,96 L0,96 Z" fill="white" opacity="0.4" />
        </svg>
      </div>
    </section>
  )
}
