// Faceless pastel flat-vector illustrations for Nestora

export const HeroIllustration = () => (
  <svg viewBox="0 0 520 420" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    {/* Background soft shapes */}
    <ellipse cx="260" cy="380" rx="220" ry="40" fill="#F9C6D3" opacity="0.3"/>
    
    {/* Ground */}
    <ellipse cx="260" cy="370" rx="200" ry="25" fill="#C8EDD9" opacity="0.5"/>

    {/* Tree left */}
    <rect x="60" y="200" width="16" height="120" rx="8" fill="#C8A97A"/>
    <circle cx="68" cy="190" r="38" fill="#A8D8A8" opacity="0.8"/>
    <circle cx="50" cy="210" r="28" fill="#C8EDD9"/>
    <circle cx="86" cy="205" r="30" fill="#9ED4B5"/>

    {/* Tree right */}
    <rect x="430" y="210" width="14" height="110" rx="7" fill="#C8A97A"/>
    <circle cx="437" cy="200" r="34" fill="#A8D8A8" opacity="0.8"/>
    <circle cx="420" cy="215" r="26" fill="#C8EDD9"/>
    <circle cx="454" cy="210" r="28" fill="#9ED4B5"/>
    
    {/* Elderly Woman - left */}
    {/* Body */}
    <rect x="105" y="195" width="52" height="90" rx="26" fill="#DDD6F3"/>
    {/* Head */}
    <circle cx="131" cy="178" r="26" fill="#FDDCBC"/>
    {/* Hair */}
    <path d="M105 168 Q131 148 157 168 Q157 155 131 150 Q105 155 105 168Z" fill="#D4C5A9"/>
    {/* Arms */}
    <path d="M105 220 Q80 235 72 255" stroke="#FDDCBC" strokeWidth="14" strokeLinecap="round"/>
    <path d="M157 220 Q182 230 190 248" stroke="#FDDCBC" strokeWidth="14" strokeLinecap="round"/>
    {/* Hands */}
    <circle cx="70" cy="258" r="10" fill="#FDDCBC"/>
    <circle cx="192" cy="251" r="10" fill="#FDDCBC"/>
    {/* Legs */}
    <rect x="113" y="278" width="18" height="52" rx="9" fill="#C8A97A"/>
    <rect x="135" y="278" width="18" height="52" rx="9" fill="#C8A97A"/>
    {/* Shoes */}
    <ellipse cx="122" cy="332" rx="14" ry="8" fill="#7C6FCD"/>
    <ellipse cx="144" cy="332" rx="14" ry="8" fill="#7C6FCD"/>
    {/* Cardigan detail */}
    <path d="M118 210 Q131 220 144 210" stroke="#B8A8E8" strokeWidth="3" fill="none"/>

    {/* Child - center holding hands with elderly */}
    {/* Body */}
    <rect x="215" y="240" width="42" height="72" rx="21" fill="#F9C6D3"/>
    {/* Head */}
    <circle cx="236" cy="224" r="22" fill="#FDDCBC"/>
    {/* Hair */}
    <path d="M214 216 Q236 198 258 216 Q256 205 236 202 Q216 205 214 216Z" fill="#8B6346"/>
    {/* Little pigtails */}
    <circle cx="214" cy="214" r="7" fill="#8B6346"/>
    <circle cx="258" cy="214" r="7" fill="#8B6346"/>
    {/* Arms reaching up */}
    <path d="M215 255 Q195 248 182 252" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>
    <path d="M257 255 Q275 248 286 250" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>
    {/* Hands */}
    <circle cx="179" cy="253" r="9" fill="#FDDCBC"/>
    <circle cx="288" cy="251" r="9" fill="#FDDCBC"/>
    {/* Legs */}
    <rect x="221" y="306" width="15" height="44" rx="7.5" fill="#C8A97A"/>
    <rect x="240" y="306" width="15" height="44" rx="7.5" fill="#C8A97A"/>
    {/* Shoes */}
    <ellipse cx="228.5" cy="351" rx="12" ry="7" fill="#F4A261"/>
    <ellipse cx="247.5" cy="351" rx="12" ry="7" fill="#F4A261"/>
    {/* Dress detail */}
    <path d="M215 260 L220 305 H252 L257 260" fill="#FFB3C6" opacity="0.5"/>

    {/* Elderly Man - right */}
    {/* Body */}
    <rect x="305" y="200" width="54" height="88" rx="27" fill="#C5DFF8"/>
    {/* Head */}
    <circle cx="332" cy="183" r="27" fill="#FDDCBC"/>
    {/* Hair - white/grey */}
    <path d="M305 174 Q332 156 359 174" stroke="#D4C5A9" strokeWidth="8" strokeLinecap="round"/>
    {/* Arms */}
    <path d="M305 225 Q282 238 272 252" stroke="#FDDCBC" strokeWidth="14" strokeLinecap="round"/>
    <path d="M359 222 Q382 232 392 248" stroke="#FDDCBC" strokeWidth="14" strokeLinecap="round"/>
    {/* Hands */}
    <circle cx="270" cy="254" r="10" fill="#FDDCBC"/>
    <circle cx="394" cy="251" r="10" fill="#FDDCBC"/>
    {/* Legs */}
    <rect x="314" y="280" width="18" height="54" rx="9" fill="#8B9DC3"/>
    <rect x="336" y="280" width="18" height="54" rx="9" fill="#8B9DC3"/>
    {/* Shoes */}
    <ellipse cx="323" cy="335" rx="14" ry="8" fill="#4A5568"/>
    <ellipse cx="345" cy="335" rx="14" ry="8" fill="#4A5568"/>
    {/* Jacket detail */}
    <path d="M318 215 Q332 225 346 215" stroke="#A5C4E8" strokeWidth="3" fill="none"/>

    {/* Holding hands connections */}
    {/* Child left hand with elderly woman right hand */}
    <path d="M179 253 Q176 252 170 252" stroke="#FDDCBC" strokeWidth="4" fill="none"/>
    <circle cx="182" cy="252" r="8" fill="#FFD4B8"/>
    
    {/* Child right hand with elderly man left hand */}
    <path d="M288 251 Q282 250 278 251" stroke="#FDDCBC" strokeWidth="4" fill="none"/>
    <circle cx="285" cy="251" r="8" fill="#FFD4B8"/>

    {/* Floating hearts */}
    <path d="M200 140 C200 135 193 130 188 135 C183 130 176 135 176 140 C176 147 188 158 188 158 C188 158 200 147 200 140Z" fill="#F9C6D3" opacity="0.8"/>
    <path d="M340 120 C340 114 332 108 326 114 C320 108 312 114 312 120 C312 128 326 140 326 140 C326 140 340 128 340 120Z" fill="#FFB3C6" opacity="0.7"/>
    <path d="M160 80 C160 76 155 72 151 76 C147 72 142 76 142 80 C142 85 151 93 151 93 C151 93 160 85 160 80Z" fill="#DDD6F3" opacity="0.9"/>
    <path d="M390 90 C390 86 385 82 381 86 C377 82 372 86 372 90 C372 95 381 103 381 103 C381 103 390 95 390 90Z" fill="#C8EDD9" opacity="0.9"/>
    <path d="M450 160 C450 155 444 150 439 155 C434 150 428 155 428 160 C428 167 439 176 439 176 C439 176 450 167 450 160Z" fill="#FDDCBC" opacity="0.8"/>

    {/* Floating dots */}
    <circle cx="90" cy="120" r="6" fill="#F9C6D3" opacity="0.6"/>
    <circle cx="430" cy="140" r="8" fill="#C8EDD9" opacity="0.6"/>
    <circle cx="480" cy="100" r="5" fill="#DDD6F3" opacity="0.7"/>
    <circle cx="40" cy="160" r="7" fill="#FDDCBC" opacity="0.6"/>
    <circle cx="260" cy="60" r="10" fill="#C5DFF8" opacity="0.5"/>
  </svg>
)

export const AboutIllustration = () => (
  <svg viewBox="0 0 420 380" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    {/* Background blob */}
    <circle cx="200" cy="200" r="170" fill="#FFF0F5" opacity="0.6"/>
    <circle cx="240" cy="180" r="140" fill="#C8EDD9" opacity="0.2"/>
    
    {/* Bench */}
    <rect x="80" y="280" width="260" height="16" rx="8" fill="#C8A97A"/>
    <rect x="100" y="296" width="16" height="40" rx="8" fill="#B8956A"/>
    <rect x="304" y="296" width="16" height="40" rx="8" fill="#B8956A"/>
    <rect x="80" y="252" width="260" height="12" rx="6" fill="#D4B896"/>

    {/* Elderly Woman reading to child */}
    {/* Elderly woman body */}
    <rect x="90" y="170" width="58" height="88" rx="29" fill="#DDD6F3"/>
    {/* Head */}
    <circle cx="119" cy="155" r="28" fill="#FDDCBC"/>
    {/* Hair bun */}
    <circle cx="119" cy="133" r="16" fill="#D4C5A9"/>
    <circle cx="119" cy="128" r="10" fill="#C8B89A"/>
    {/* Arms holding book */}
    <path d="M90 210 Q68 220 64 238" stroke="#FDDCBC" strokeWidth="15" strokeLinecap="round"/>
    <path d="M148 210 Q168 218 172 238" stroke="#FDDCBC" strokeWidth="15" strokeLinecap="round"/>
    {/* Book */}
    <rect x="58" y="232" width="120" height="82" rx="8" fill="#F4E4C1"/>
    <rect x="58" y="232" width="58" height="82" rx="8" fill="#E8D4A0"/>
    <line x1="118" y1="232" x2="118" y2="314" stroke="#D4B896" strokeWidth="3"/>
    {/* Book lines */}
    <line x1="72" y1="255" x2="110" y2="255" stroke="#C8A97A" strokeWidth="2" opacity="0.6"/>
    <line x1="72" y1="268" x2="105" y2="268" stroke="#C8A97A" strokeWidth="2" opacity="0.6"/>
    <line x1="72" y1="281" x2="108" y2="281" stroke="#C8A97A" strokeWidth="2" opacity="0.6"/>
    <line x1="126" y1="255" x2="165" y2="255" stroke="#C8A97A" strokeWidth="2" opacity="0.6"/>
    <line x1="126" y1="268" x2="162" y2="268" stroke="#C8A97A" strokeWidth="2" opacity="0.6"/>

    {/* Child sitting listening */}
    {/* Body */}
    <rect x="250" y="218" width="44" height="66" rx="22" fill="#F9C6D3"/>
    {/* Head */}
    <circle cx="272" cy="203" r="23" fill="#FDDCBC"/>
    {/* Hair */}
    <path d="M249 195 Q272 178 295 195 Q293 184 272 180 Q251 184 249 195Z" fill="#5D3A1A"/>
    {/* Legs dangling off bench */}
    <rect x="257" y="280" width="14" height="46" rx="7" fill="#C8A97A"/>
    <rect x="275" y="280" width="14" height="46" rx="7" fill="#C8A97A"/>
    {/* Shoes swinging */}
    <ellipse cx="264" cy="328" rx="12" ry="7" fill="#F4A261"/>
    <ellipse cx="282" cy="328" rx="12" ry="7" fill="#F4A261"/>
    {/* Arms on lap */}
    <path d="M250 238 Q240 248 238 258" stroke="#FDDCBC" strokeWidth="12" strokeLinecap="round"/>
    <path d="M294 238 Q304 248 306 258" stroke="#FDDCBC" strokeWidth="12" strokeLinecap="round"/>

    {/* Floating stars/sparkles around book */}
    <path d="M200 148 L202 155 L209 155 L203 160 L205 167 L200 162 L195 167 L197 160 L191 155 L198 155 Z" fill="#FFD700" opacity="0.7"/>
    <path d="M230 130 L231 135 L236 135 L232 138 L233 143 L230 140 L227 143 L228 138 L224 135 L229 135 Z" fill="#F9C6D3"/>
    <path d="M170 130 L171.5 136 L178 136 L173 140 L174.5 146 L170 142 L165.5 146 L167 140 L162 136 L168.5 136 Z" fill="#C8EDD9"/>

    {/* Floating butterfly */}
    <ellipse cx="360" cy="160" rx="18" ry="12" fill="#DDD6F3" opacity="0.8" transform="rotate(-30 360 160)"/>
    <ellipse cx="346" cy="155" rx="14" ry="9" fill="#C5DFF8" opacity="0.8" transform="rotate(30 346 155)"/>
    <line x1="353" y1="157" x2="353" y2="165" stroke="#7C6FCD" strokeWidth="2"/>
  </svg>
)

export const StorytellingIllustration = () => (
  <svg viewBox="0 0 360 300" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    {/* Soft bg */}
    <circle cx="180" cy="160" r="130" fill="#FDDCBC" opacity="0.2"/>
    
    {/* Rug/mat */}
    <ellipse cx="180" cy="240" rx="150" ry="30" fill="#F9C6D3" opacity="0.4"/>

    {/* Elderly man storytelling */}
    {/* Chair */}
    <rect x="50" y="160" width="80" height="80" rx="10" fill="#E8D4A0"/>
    <rect x="50" y="145" width="80" height="25" rx="8" fill="#D4B896"/>
    <rect x="40" y="225" width="14" height="40" rx="7" fill="#C8A97A"/>
    <rect x="116" y="225" width="14" height="40" rx="7" fill="#C8A97A"/>
    {/* Body */}
    <rect x="65" y="130" width="54" height="88" rx="27" fill="#C5DFF8"/>
    {/* Head */}
    <circle cx="92" cy="114" r="26" fill="#FDDCBC"/>
    {/* Hair */}
    <path d="M66 108 Q92 92 118 108" stroke="#D4C5A9" strokeWidth="9" strokeLinecap="round"/>
    {/* Arm raised telling story */}
    <path d="M119 165 Q145 150 155 130" stroke="#FDDCBC" strokeWidth="14" strokeLinecap="round"/>
    <circle cx="157" cy="127" r="10" fill="#FDDCBC"/>
    {/* Other arm on armrest */}
    <path d="M65 172 Q50 180 45 195" stroke="#FDDCBC" strokeWidth="14" strokeLinecap="round"/>
    <circle cx="43" cy="197" r="9" fill="#FDDCBC"/>

    {/* Child 1 sitting on floor */}
    <circle cx="210" cy="195" r="20" fill="#FDDCBC"/>
    <path d="M190 190 Q210 174 230 190 Q228 180 210 176 Q192 180 190 190Z" fill="#A0522D"/>
    <rect x="195" y="210" width="30" height="40" rx="15" fill="#F9C6D3"/>
    <path d="M185 215 Q178 228 176 238" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>
    <path d="M225 215 Q232 228 234 238" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>
    <path d="M195 245 Q200 260 200 268" stroke="#C8A97A" strokeWidth="11" strokeLinecap="round"/>
    <path d="M225 245 Q220 260 220 268" stroke="#C8A97A" strokeWidth="11" strokeLinecap="round"/>

    {/* Child 2 sitting */}
    <circle cx="280" cy="198" r="19" fill="#FDDCBC"/>
    <path d="M261 193 Q280 178 299 193 Q297 183 280 179 Q263 183 261 193Z" fill="#3D2C2C"/>
    <rect x="265" y="213" width="30" height="38" rx="15" fill="#C8EDD9"/>
    <path d="M255 218 Q248 230 246 240" stroke="#FDDCBC" strokeWidth="10" strokeLinecap="round"/>
    <path d="M295 218 Q302 230 304 240" stroke="#FDDCBC" strokeWidth="10" strokeLinecap="round"/>
    <path d="M265 248 Q261 262 261 270" stroke="#C8A97A" strokeWidth="10" strokeLinecap="round"/>
    <path d="M293 248 Q297 262 297 270" stroke="#C8A97A" strokeWidth="10" strokeLinecap="round"/>

    {/* Story cloud/imagination bubble */}
    <circle cx="220" cy="70" r="35" fill="white" opacity="0.8"/>
    <circle cx="200" cy="80" r="20" fill="white" opacity="0.8"/>
    <circle cx="240" cy="82" r="22" fill="white" opacity="0.8"/>
    <circle cx="182" cy="95" r="12" fill="white" opacity="0.7"/>
    <circle cx="190" cy="105" r="8" fill="white" opacity="0.6"/>
    <circle cx="198" cy="112" r="5" fill="white" opacity="0.5"/>
    {/* Dragon in story cloud */}
    <path d="M200 60 Q220 50 240 60 Q245 70 230 75 Q220 65 210 75 Q195 70 200 60Z" fill="#C8EDD9"/>
    <circle cx="213" cy="60" r="5" fill="#A8D8A8"/>
    <circle cx="225" cy="58" r="5" fill="#A8D8A8"/>

    {/* Floating sparkles */}
    <circle cx="160" cy="80" r="5" fill="#F9C6D3" opacity="0.8"/>
    <circle cx="310" cy="120" r="4" fill="#DDD6F3" opacity="0.8"/>
    <circle cx="330" cy="80" r="6" fill="#C5DFF8" opacity="0.7"/>
  </svg>
)

export const GardeningIllustration = () => (
  <svg viewBox="0 0 380 320" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    <circle cx="190" cy="180" r="150" fill="#C8EDD9" opacity="0.2"/>
    
    {/* Ground / garden bed */}
    <ellipse cx="190" cy="280" rx="170" ry="28" fill="#8B6B3D" opacity="0.4"/>
    <rect x="40" y="262" width="300" height="22" rx="11" fill="#A0784A" opacity="0.5"/>

    {/* Plants/flowers */}
    <rect x="80" y="230" width="10" height="38" rx="5" fill="#6DB37E"/>
    <circle cx="85" cy="222" r="18" fill="#FF8FAB"/>
    <circle cx="75" cy="228" r="12" fill="#FF6B9D"/>
    <circle cx="95" cy="226" r="13" fill="#FFB3C6"/>

    <rect x="170" y="220" width="10" height="46" rx="5" fill="#6DB37E"/>
    <circle cx="175" cy="212" r="16" fill="#FFD93D"/>
    <circle cx="164" cy="218" r="11" fill="#FFC107"/>
    <circle cx="186" cy="215" r="12" fill="#FFE066"/>

    <rect x="290" y="228" width="10" height="38" rx="5" fill="#6DB37E"/>
    <circle cx="295" cy="220" r="17" fill="#C8EDD9"/>
    <circle cx="283" cy="226" r="11" fill="#9ED4B5"/>
    <circle cx="306" cy="223" r="13" fill="#B8EAD0"/>

    {/* Smaller plants */}
    <rect x="130" y="242" width="8" height="26" rx="4" fill="#6DB37E"/>
    <circle cx="134" cy="236" r="13" fill="#F4A261" opacity="0.9"/>
    
    <rect x="235" y="240" width="8" height="28" rx="4" fill="#6DB37E"/>
    <circle cx="239" cy="233" r="12" fill="#DDD6F3"/>

    {/* Elderly woman gardening */}
    {/* Hat */}
    <ellipse cx="120" cy="105" rx="34" ry="10" fill="#E8D4A0"/>
    <circle cx="120" cy="100" r="22" fill="#D4B896"/>
    {/* Head */}
    <circle cx="120" cy="115" r="24" fill="#FDDCBC"/>
    {/* Body */}
    <rect x="96" y="134" width="48" height="82" rx="24" fill="#F9C6D3"/>
    {/* Apron */}
    <rect x="104" y="148" width="32" height="52" rx="8" fill="#FFF0F5" opacity="0.8"/>
    {/* Arms */}
    <path d="M96 158 Q74 168 62 188" stroke="#FDDCBC" strokeWidth="13" strokeLinecap="round"/>
    <path d="M144 155 Q162 162 168 178" stroke="#FDDCBC" strokeWidth="13" strokeLinecap="round"/>
    {/* Hands */}
    <circle cx="60" cy="191" r="9" fill="#FDDCBC"/>
    <circle cx="170" cy="181" r="9" fill="#FDDCBC"/>
    {/* Small trowel */}
    <rect x="164" y="173" width="6" height="22" rx="3" fill="#8B9DC3"/>
    <ellipse cx="167" cy="198" rx="7" ry="5" fill="#A0784A"/>
    {/* Legs */}
    <rect x="103" y="210" width="16" height="52" rx="8" fill="#C8A97A"/>
    <rect x="124" y="210" width="16" height="52" rx="8" fill="#C8A97A"/>
    <ellipse cx="111" cy="263" rx="13" ry="7" fill="#8B6B3D"/>
    <ellipse cx="132" cy="263" rx="13" ry="7" fill="#8B6B3D"/>

    {/* Child watering */}
    {/* Head */}
    <circle cx="270" cy="148" r="21" fill="#FDDCBC"/>
    {/* Hair pigtails */}
    <path d="M249 142 Q270 126 291 142 Q289 132 270 128 Q251 132 249 142Z" fill="#8B6346"/>
    <circle cx="249" cy="140" r="8" fill="#8B6346"/>
    <circle cx="291" cy="140" r="8" fill="#8B6346"/>
    {/* Body */}
    <rect x="249" y="164" width="42" height="70" rx="21" fill="#C5DFF8"/>
    {/* Arms */}
    <path d="M249 178 Q228 172 218 178" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>
    <path d="M291 175 Q312 168 320 172" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>
    {/* Watering can */}
    <rect x="316" y="160" width="28" height="22" rx="6" fill="#C5DFF8"/>
    <path d="M344 170 Q360 165 362 175" stroke="#8B9DC3" strokeWidth="5" fill="none" strokeLinecap="round"/>
    <rect x="320" y="155" width="14" height="8" rx="4" fill="#8B9DC3"/>
    {/* Water drops */}
    <ellipse cx="368" cy="185" rx="3" ry="5" fill="#C5DFF8"/>
    <ellipse cx="362" cy="195" rx="3" ry="5" fill="#C5DFF8"/>
    <ellipse cx="356" cy="188" rx="2.5" ry="4" fill="#C5DFF8"/>
    {/* Legs */}
    <rect x="256" y="230" width="14" height="46" rx="7" fill="#C8A97A"/>
    <rect x="274" y="230" width="14" height="46" rx="7" fill="#C8A97A"/>
    <ellipse cx="263" cy="278" rx="12" ry="7" fill="#4A5568"/>
    <ellipse cx="281" cy="278" rx="12" ry="7" fill="#4A5568"/>

    {/* Butterflies */}
    <ellipse cx="200" cy="60" rx="16" ry="10" fill="#DDD6F3" opacity="0.8" transform="rotate(-25 200 60)"/>
    <ellipse cx="186" cy="55" rx="12" ry="8" fill="#C5DFF8" opacity="0.8" transform="rotate(25 186 55)"/>
    <circle cx="193" cy="58" r="4" fill="#7C6FCD"/>

    {/* Sun */}
    <circle cx="340" cy="50" r="28" fill="#FFD93D" opacity="0.6"/>
    <circle cx="340" cy="50" r="20" fill="#FFE066" opacity="0.7"/>
  </svg>
)

export const DiningIllustration = () => (
  <svg viewBox="0 0 400 340" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    <circle cx="200" cy="180" r="160" fill="#FDDCBC" opacity="0.15"/>
    
    {/* Table */}
    <ellipse cx="200" cy="248" rx="140" ry="30" fill="#D4B896"/>
    <ellipse cx="200" cy="242" rx="140" ry="30" fill="#E8D4A0"/>
    {/* Table legs */}
    <rect x="80" y="265" width="14" height="60" rx="7" fill="#C8A97A"/>
    <rect x="306" y="265" width="14" height="60" rx="7" fill="#C8A97A"/>
    
    {/* Food on table */}
    <circle cx="200" cy="230" r="28" fill="#FFF8F0"/>
    <circle cx="200" cy="230" r="22" fill="#F4A261" opacity="0.5"/>
    {/* Bowl steam */}
    <path d="M190 205 Q192 195 190 185" stroke="#DDD6F3" strokeWidth="3" fill="none" strokeLinecap="round"/>
    <path d="M200 203 Q202 193 200 183" stroke="#DDD6F3" strokeWidth="3" fill="none" strokeLinecap="round"/>
    <path d="M210 205 Q212 195 210 185" stroke="#DDD6F3" strokeWidth="3" fill="none" strokeLinecap="round"/>
    
    {/* Plates sides */}
    <circle cx="128" cy="238" r="22" fill="#FFF8F0"/>
    <circle cx="128" cy="238" r="17" fill="#F9C6D3" opacity="0.6"/>
    <circle cx="272" cy="238" r="22" fill="#FFF8F0"/>
    <circle cx="272" cy="238" r="17" fill="#C8EDD9" opacity="0.6"/>
    
    {/* Cups */}
    <rect x="155" y="218" width="16" height="20" rx="4" fill="#C5DFF8"/>
    <rect x="229" y="218" width="16" height="20" rx="4" fill="#F9C6D3"/>

    {/* Person left - elderly man */}
    <circle cx="90" cy="155" r="25" fill="#FDDCBC"/>
    <path d="M65 148 Q90 132 115 148" stroke="#D4C5A9" strokeWidth="8" strokeLinecap="round"/>
    <rect x="68" y="174" width="44" height="72" rx="22" fill="#C5DFF8"/>
    <path d="M68 194 Q48 202 44 218" stroke="#FDDCBC" strokeWidth="12" strokeLinecap="round"/>
    <path d="M112 192 Q130 200 134 215" stroke="#FDDCBC" strokeWidth="12" strokeLinecap="round"/>
    <circle cx="43" cy="220" r="9" fill="#FDDCBC"/>
    <circle cx="136" cy="218" r="9" fill="#FDDCBC"/>

    {/* Person center - child */}
    <circle cx="200" cy="140" r="20" fill="#FDDCBC"/>
    <path d="M180 134 Q200 119 220 134 Q218 125 200 121 Q182 125 180 134Z" fill="#8B6346"/>
    <rect x="183" y="155" width="34" height="62" rx="17" fill="#F9C6D3"/>
    <path d="M183 170 Q166 178 162 192" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>
    <path d="M217 168 Q234 176 238 190" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>

    {/* Person right - elderly woman */}
    <circle cx="310" cy="152" r="25" fill="#FDDCBC"/>
    <circle cx="310" cy="132" r="14" fill="#D4C5A9"/>
    <circle cx="310" cy="128" r="9" fill="#C8B89A"/>
    <rect x="288" y="170" width="44" height="72" rx="22" fill="#DDD6F3"/>
    <path d="M288 190 Q270 198 266 214" stroke="#FDDCBC" strokeWidth="12" strokeLinecap="round"/>
    <path d="M332 188 Q350 196 354 212" stroke="#FDDCBC" strokeWidth="12" strokeLinecap="round"/>
    <circle cx="264" cy="216" r="9" fill="#FDDCBC"/>
    <circle cx="356" cy="214" r="9" fill="#FDDCBC"/>

    {/* Small floating hearts */}
    <path d="M185 88 C185 84 179 80 175 84 C171 80 165 84 165 88 C165 94 175 103 175 103 C175 103 185 94 185 88Z" fill="#F9C6D3" opacity="0.8"/>
    <path d="M240 78 C240 75 236 72 233 75 C230 72 226 75 226 78 C226 83 233 90 233 90 C233 90 240 83 240 78Z" fill="#FDDCBC" opacity="0.8"/>
  </svg>
)

export const PaintingIllustration = () => (
  <svg viewBox="0 0 360 300" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    <circle cx="180" cy="160" r="140" fill="#DDD6F3" opacity="0.15"/>
    
    {/* Easel */}
    <line x1="180" y1="80" x2="120" y2="270" stroke="#C8A97A" strokeWidth="8" strokeLinecap="round"/>
    <line x1="180" y1="80" x2="240" y2="270" stroke="#C8A97A" strokeWidth="8" strokeLinecap="round"/>
    <line x1="130" y1="200" x2="230" y2="200" stroke="#C8A97A" strokeWidth="6" strokeLinecap="round"/>
    {/* Canvas */}
    <rect x="135" y="80" width="90" height="108" rx="6" fill="white"/>
    <rect x="140" y="85" width="80" height="98" rx="4" fill="#FFF8F0"/>
    {/* Painting on canvas */}
    <circle cx="180" cy="120" r="22" fill="#FFD93D" opacity="0.7"/>
    <path d="M145 150 Q165 135 180 145 Q195 135 215 150" fill="#6DB37E" opacity="0.7"/>
    <rect x="152" y="148" width="56" height="28" rx="4" fill="#A8D8A8" opacity="0.5"/>

    {/* Elderly woman painting */}
    <circle cx="90" cy="130" r="25" fill="#FDDCBC"/>
    <circle cx="90" cy="111" r="14" fill="#D4C5A9"/>
    <circle cx="90" cy="107" r="9" fill="#C8B89A"/>
    <rect x="68" y="148" width="44" height="80" rx="22" fill="#F9C6D3"/>
    {/* Arm holding brush toward canvas */}
    <path d="M112 165 Q132 155 145 148" stroke="#FDDCBC" strokeWidth="13" strokeLinecap="round"/>
    <circle cx="147" cy="147" r="9" fill="#FDDCBC"/>
    {/* Brush */}
    <line x1="148" y1="143" x2="152" y2="116" stroke="#C8A97A" strokeWidth="5" strokeLinecap="round"/>
    <ellipse cx="153" cy="112" rx="5" ry="8" fill="#E8748A"/>
    {/* Other arm */}
    <path d="M68 172 Q50 180 46 196" stroke="#FDDCBC" strokeWidth="13" strokeLinecap="round"/>
    {/* Palette */}
    <ellipse cx="48" cy="200" rx="16" ry="12" fill="#FFF8F0"/>
    <circle cx="42" cy="196" r="5" fill="#F9C6D3"/>
    <circle cx="52" cy="194" r="5" fill="#C8EDD9"/>
    <circle cx="58" cy="200" r="5" fill="#C5DFF8"/>
    <circle cx="50" cy="207" r="5" fill="#FFD93D"/>
    {/* Legs */}
    <rect x="76" y="222" width="14" height="50" rx="7" fill="#C8A97A"/>
    <rect x="96" y="222" width="14" height="50" rx="7" fill="#C8A97A"/>

    {/* Child painting beside */}
    <circle cx="270" cy="155" r="20" fill="#FDDCBC"/>
    <path d="M250 149 Q270 134 290 149 Q288 140 270 136 Q252 140 250 149Z" fill="#5D3A1A"/>
    <rect x="252" y="170" width="36" height="68" rx="18" fill="#C5DFF8"/>
    {/* Own small easel */}
    <line x1="295" y1="140" x2="268" y2="230" stroke="#C8A97A" strokeWidth="6" strokeLinecap="round"/>
    <line x1="295" y1="140" x2="318" y2="230" stroke="#C8A97A" strokeWidth="6" strokeLinecap="round"/>
    <rect x="275" y="138" width="40" height="52" rx="5" fill="white"/>
    <rect x="279" y="142" width="32" height="44" rx="3" fill="#FFF0F5"/>
    {/* Child painting */}
    <circle cx="295" cy="160" r="10" fill="#F9C6D3" opacity="0.8"/>
    <path d="M281 175 Q295 168 309 175" fill="#C8EDD9" opacity="0.7"/>
    {/* Arm with brush */}
    <path d="M252 180 Q238 170 232 160" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>
    <line x1="231" y1="158" x2="228" y2="140" stroke="#C8A97A" strokeWidth="4" strokeLinecap="round"/>
    <ellipse cx="228" cy="137" rx="4" ry="6" fill="#7C6FCD"/>
    {/* Other arm */}
    <path d="M288 178 Q305 170 312 180" stroke="#FDDCBC" strokeWidth="11" strokeLinecap="round"/>

    {/* Colorful paint splatters */}
    <circle cx="160" cy="260" r="8" fill="#F9C6D3" opacity="0.6"/>
    <circle cx="180" cy="268" r="5" fill="#C8EDD9" opacity="0.6"/>
    <circle cx="200" cy="258" r="7" fill="#C5DFF8" opacity="0.6"/>
    <circle cx="140" cy="265" r="6" fill="#DDD6F3" opacity="0.6"/>
  </svg>
)

export const SafetyIllustration = () => (
  <svg viewBox="0 0 380 320" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    <circle cx="190" cy="160" r="150" fill="#C8EDD9" opacity="0.2"/>
    
    {/* Shield */}
    <path d="M190 40 L290 80 L290 180 Q290 240 190 280 Q90 240 90 180 L90 80 Z" fill="#C8EDD9" opacity="0.5"/>
    <path d="M190 55 L278 90 L278 178 Q278 232 190 268 Q102 232 102 178 L102 90 Z" fill="white" opacity="0.6"/>
    
    {/* Checkmark in shield */}
    <path d="M145 170 L175 200 L240 135" stroke="#6DB37E" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round"/>

    {/* Family figures inside shield area */}
    {/* Adult */}
    <circle cx="165" cy="145" r="18" fill="#FDDCBC"/>
    <rect x="150" y="158" width="30" height="52" rx="15" fill="#DDD6F3"/>
    {/* Child beside adult */}
    <circle cx="210" cy="152" r="15" fill="#FDDCBC"/>
    <rect x="197" y="163" width="26" height="44" rx="13" fill="#F9C6D3"/>
    {/* Holding hands */}
    <path d="M180 172 Q192 170 196 168" stroke="#FDDCBC" strokeWidth="8" strokeLinecap="round"/>

    {/* Stars around shield */}
    <path d="M60 80 L62 88 L70 88 L64 93 L66 101 L60 96 L54 101 L56 93 L50 88 L58 88 Z" fill="#FFD93D" opacity="0.7"/>
    <path d="M310 60 L312 68 L320 68 L314 73 L316 81 L310 76 L304 81 L306 73 L300 68 L308 68 Z" fill="#F9C6D3"/>
    <path d="M330 180 L331.5 186 L338 186 L333 190 L334.5 196 L330 192 L325.5 196 L327 190 L322 186 L328.5 186 Z" fill="#C8EDD9"/>
    <path d="M42 200 L43.5 206 L50 206 L45 210 L46.5 216 L42 212 L37.5 216 L39 210 L34 206 L40.5 206 Z" fill="#DDD6F3"/>
  </svg>
)
