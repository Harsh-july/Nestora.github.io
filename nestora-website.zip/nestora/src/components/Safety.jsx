import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { ShieldCheck, Camera, UserCheck, Apple, Baby, Stethoscope, Bell } from 'lucide-react'
import { SafetyIllustration } from './Illustrations'

const safetyItems = [
  {
    icon: <ShieldCheck className="w-5 h-5" />,
    title: 'Sanitized Environment',
    desc: 'Daily deep cleaning protocols and hospital-grade sanitization throughout all spaces.',
    color: 'from-emerald-400 to-teal-400',
  },
  {
    icon: <Camera className="w-5 h-5" />,
    title: 'CCTV Monitoring',
    desc: '24/7 camera surveillance in all common areas with live parent access via mobile app.',
    color: 'from-blue-400 to-indigo-400',
  },
  {
    icon: <UserCheck className="w-5 h-5" />,
    title: 'Verified Caregivers',
    desc: 'All staff and elder companions undergo thorough background checks and regular training.',
    color: 'from-violet-400 to-purple-400',
  },
  {
    icon: <Apple className="w-5 h-5" />,
    title: 'Balanced Nutrition',
    desc: 'Dietitian-approved meal plans ensuring optimal nutrition for every age group.',
    color: 'from-orange-400 to-amber-400',
  },
  {
    icon: <Baby className="w-5 h-5" />,
    title: 'Child-Safe Infrastructure',
    desc: 'Rounded edges, padded floors, safety gates, and age-appropriate equipment throughout.',
    color: 'from-rose-400 to-pink-400',
  },
  {
    icon: <Stethoscope className="w-5 h-5" />,
    title: 'Medical Support',
    desc: 'On-call medical staff and a fully equipped first-aid room for immediate care.',
    color: 'from-red-400 to-rose-400',
  },
  {
    icon: <Bell className="w-5 h-5" />,
    title: 'Emergency Assistance',
    desc: 'Clear emergency protocols, trained response teams, and hospital partnerships.',
    color: 'from-amber-400 to-yellow-400',
  },
]

export default function Safety() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="safety" className="py-24 lg:py-32 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-100 px-4 py-2 rounded-full mb-6">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span className="font-body text-sm text-emerald-600 font-medium">Safety First, Always</span>
            </div>
            <h2 className="font-display font-extrabold text-4xl lg:text-5xl text-[#3D2C2C] leading-tight mb-6">
              Your Peace of Mind{' '}
              <span className="text-gradient-cool">Is Our Priority</span>
            </h2>
            <p className="font-body text-lg text-[#6B5B5B] leading-relaxed mb-10">
              Every system at Nestora is designed to keep your loved ones safe, healthy, and completely cared for — so you can trust us with what matters most.
            </p>

            <div className="grid sm:grid-cols-2 gap-4">
              {safetyItems.map((item, i) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.2 + i * 0.08, duration: 0.6 }}
                  className="group flex items-start gap-3 p-4 rounded-2xl hover:bg-[#FFF8F0] transition-colors"
                >
                  <div className={`flex-shrink-0 w-9 h-9 rounded-xl bg-gradient-to-br ${item.color} text-white flex items-center justify-center group-hover:scale-110 transition-transform shadow-soft`}>
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-display font-semibold text-sm text-[#3D2C2C] mb-0.5">{item.title}</h4>
                    <p className="font-body text-xs text-[#9B8B8B] leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Illustration */}
          <motion.div
            initial={{ opacity: 0, x: 50, scale: 0.92 }}
            animate={isInView ? { opacity: 1, x: 0, scale: 1 } : {}}
            transition={{ duration: 0.9, delay: 0.3 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-100/50 via-cream to-blue-100/50 rounded-[48px] blur-3xl" />
            
            <motion.div
              animate={{ y: [-6, 6, -6] }}
              transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
              className="relative"
            >
              <div className="glass rounded-[40px] p-8 shadow-soft">
                <SafetyIllustration />
              </div>
            </motion.div>

            {/* Trust badges */}
            <motion.div
              animate={{ y: [-4, 4, -4] }}
              transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -top-6 left-6 glass rounded-2xl px-4 py-3 shadow-soft"
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-400 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="font-display font-bold text-xs text-[#3D2C2C]">100% Verified</p>
                  <p className="font-body text-xs text-[#9B8B8B]">All Staff</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              animate={{ y: [4, -4, 4] }}
              transition={{ duration: 4, delay: 1, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -bottom-4 right-6 glass rounded-2xl px-4 py-3 shadow-soft"
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-400 to-indigo-400 flex items-center justify-center">
                  <Camera className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="font-display font-bold text-xs text-[#3D2C2C]">24/7 CCTV</p>
                  <p className="font-body text-xs text-[#9B8B8B]">Live Access</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
