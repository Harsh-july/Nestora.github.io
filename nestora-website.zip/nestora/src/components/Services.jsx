import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { Baby, BookOpen, Palette, Utensils, Heart, Users, Home, Smile } from 'lucide-react'

const childrenServices = [
  { icon: <Baby className="w-4 h-4" />, title: 'Full-Day Daycare', desc: 'Safe, engaging, and nurturing full-day care for children aged 1–10.' },
  { icon: <BookOpen className="w-4 h-4" />, title: 'Learning Activities', desc: 'Structured play-based learning with early literacy, numeracy, and arts.' },
  { icon: <Heart className="w-4 h-4" />, title: 'Storytelling Sessions', desc: 'Magical storytelling circles led by our beloved elder companions.' },
  { icon: <Palette className="w-4 h-4" />, title: 'Creative Play', desc: 'Art, music, gardening, and imaginative play that fuels young minds.' },
  { icon: <Utensils className="w-4 h-4" />, title: 'Healthy Meals', desc: 'Balanced, age-appropriate meals crafted for growing bodies.' },
  { icon: <Smile className="w-4 h-4" />, title: 'Emotional Care', desc: 'Trained staff and warm elders who prioritize emotional wellbeing.' },
]

const elderServices = [
  { icon: <Home className="w-4 h-4" />, title: 'Community Living', desc: 'Free residential facilities in a vibrant, purposeful community setting.' },
  { icon: <Users className="w-4 h-4" />, title: 'Engagement Activities', desc: 'Yoga, crafts, gardening, music — staying active and joyful every day.' },
  { icon: <Heart className="w-4 h-4" />, title: 'Social Wellness', desc: 'Regular social gatherings, celebrations, and community events.' },
  { icon: <BookOpen className="w-4 h-4" />, title: 'Caregiver Role', desc: 'Become a storyteller, mentor, or activity guide for the children.' },
  { icon: <Smile className="w-4 h-4" />, title: 'Companionship', desc: 'Daily meaningful interactions with children and peers to end loneliness.' },
  { icon: <Utensils className="w-4 h-4" />, title: 'Nutrition & Wellness', desc: 'Carefully curated diet plans and wellness checks by trained professionals.' },
]

function ServiceCard({ service, color }) {
  return (
    <motion.div
      whileHover={{ x: 4 }}
      className="flex items-start gap-3 p-4 rounded-2xl hover:bg-white/60 transition-all duration-200 group"
    >
      <div className={`w-8 h-8 flex-shrink-0 rounded-xl ${color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
        {service.icon}
      </div>
      <div>
        <h4 className="font-display font-semibold text-sm text-[#3D2C2C] mb-0.5">{service.title}</h4>
        <p className="font-body text-xs text-[#8B7B7B] leading-relaxed">{service.desc}</p>
      </div>
    </motion.div>
  )
}

export default function Services() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="services" className="py-24 lg:py-32 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-100 px-4 py-2 rounded-full mb-6">
            <Heart className="w-4 h-4 text-emerald-500" />
            <span className="font-body text-sm text-emerald-600 font-medium">Our Services</span>
          </div>
          <h2 className="font-display font-extrabold text-4xl lg:text-5xl text-[#3D2C2C] mb-5">
            Care for Every{' '}
            <span className="text-gradient-warm">Generation</span>
          </h2>
          <p className="font-body text-lg text-[#6B5B5B] max-w-2xl mx-auto">
            Thoughtfully designed services that meet every need — for the little ones who are just beginning, and the wise ones who have lived fully.
          </p>
        </motion.div>

        {/* Service columns */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Children */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="rounded-3xl bg-gradient-to-br from-rose-50 via-pink-50 to-peach-light p-8 border border-rose-100"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-rose-300 to-orange-200 flex items-center justify-center">
                <Baby className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-body text-xs text-rose-400 font-medium uppercase tracking-wider">For</div>
                <h3 className="font-display font-extrabold text-xl text-[#3D2C2C]">Children</h3>
              </div>
            </div>
            <div className="space-y-1">
              {childrenServices.map((s) => (
                <ServiceCard key={s.title} service={s} color="bg-rose-100 text-rose-400" />
              ))}
            </div>
          </motion.div>

          {/* Elderly */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="rounded-3xl bg-gradient-to-br from-violet-50 via-lavender-light to-powder-light p-8 border border-violet-100"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-300 to-blue-200 flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-body text-xs text-violet-400 font-medium uppercase tracking-wider">For</div>
                <h3 className="font-display font-extrabold text-xl text-[#3D2C2C]">Elderly</h3>
              </div>
            </div>
            <div className="space-y-1">
              {elderServices.map((s) => (
                <ServiceCard key={s.title} service={s} color="bg-violet-100 text-violet-500" />
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
