import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef, useState } from 'react'
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react'

const testimonials = [
  {
    name: 'Priya Sharma',
    role: 'Parent of Arjun, 4 years',
    avatar: '👩',
    color: 'from-rose-100 to-pink-100',
    stars: 5,
    text: "Nestora changed our family's life. Arjun used to be shy and anxious, but after six months here, he comes home glowing. He talks about 'Nani Geeta' every day — an 80-year-old resident who tells him the most magical stories. I cry every time I pick him up because I see how genuinely happy he is.",
  },
  {
    name: 'Ramesh Iyer',
    role: 'Elder Resident, 74 years',
    avatar: '👴',
    color: 'from-blue-100 to-powder-light',
    stars: 5,
    text: "After my wife passed, I felt invisible. My children were busy, and the silence was unbearable. Then I moved to Nestora. Now, every morning a little girl named Meera saves a seat for me at breakfast. She says I tell the best stories. I haven't felt this needed in years. This place gave me back my reason to wake up.",
  },
  {
    name: 'Sunita & Vikram Mehta',
    role: 'Parents of twins, 6 years',
    avatar: '👫',
    color: 'from-amber-100 to-yellow-50',
    stars: 5,
    text: "We were skeptical at first — mixing children with elderly? But nothing could have prepared us for what we witnessed. Our twins now tie their shoelaces with patience they learned from Uncle Mohan, and they speak about old age with such tenderness. Nestora isn't just childcare — it's where emotional intelligence is born.",
  },
  {
    name: 'Kavitha Nair',
    role: 'Elder Resident, 68 years',
    avatar: '👵',
    color: 'from-violet-100 to-lavender-light',
    stars: 5,
    text: "I teach art here, and the children look at me like I'm the most important person in the world. My arthritis still bothers me, but the moment those tiny hands take the brush from me and copy my strokes, I forget all pain. This isn't retirement — this is the most beautiful chapter of my life.",
  },
  {
    name: 'Aditya Khanna',
    role: 'Parent of Isha, 3 years',
    avatar: '👨',
    color: 'from-emerald-100 to-mint-light',
    stars: 5,
    text: "Isha learned to say 'sorry' from an elderly resident who forgave her after she accidentally knocked over his puzzle. He hugged her and said 'we all make mistakes, little one.' She came home that day and apologized to our dog. The kindness this place teaches is real and deep.",
  },
]

function StarRating({ count }) {
  return (
    <div className="flex gap-0.5">
      {[...Array(count)].map((_, i) => (
        <Star key={i} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
      ))}
    </div>
  )
}

export default function Testimonials() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })
  const [current, setCurrent] = useState(0)

  const prev = () => setCurrent((c) => (c - 1 + testimonials.length) % testimonials.length)
  const next = () => setCurrent((c) => (c + 1) % testimonials.length)

  return (
    <section id="testimonials" className="py-24 lg:py-32 bg-[#FFF8F0] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-100 px-4 py-2 rounded-full mb-6">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span className="font-body text-sm text-amber-600 font-medium">Stories of Connection</span>
          </div>
          <h2 className="font-display font-extrabold text-4xl lg:text-5xl text-[#3D2C2C] mb-5">
            Voices from Our{' '}
            <span className="text-gradient-warm">Community</span>
          </h2>
          <p className="font-body text-lg text-[#6B5B5B] max-w-2xl mx-auto">
            The most meaningful stories are the ones written by the families and elders who call Nestora home.
          </p>
        </motion.div>

        {/* Desktop grid */}
        <div className="hidden lg:grid lg:grid-cols-3 gap-6">
          {testimonials.slice(0, 3).map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.1, duration: 0.7 }}
              whileHover={{ y: -8 }}
              className={`bg-gradient-to-br ${t.color} rounded-3xl p-6 shadow-softer hover:shadow-soft transition-all duration-300 border border-white relative overflow-hidden`}
            >
              <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-white/30 -translate-y-1/2 translate-x-1/2" />
              <Quote className="w-8 h-8 text-rose-200 mb-4" />
              <StarRating count={t.stars} />
              <p className="font-body text-sm text-[#6B5B5B] leading-relaxed my-4 italic">"{t.text}"</p>
              <div className="flex items-center gap-3 pt-4 border-t border-white/60">
                <div className="w-10 h-10 rounded-full bg-white/60 flex items-center justify-center text-xl">{t.avatar}</div>
                <div>
                  <p className="font-display font-bold text-sm text-[#3D2C2C]">{t.name}</p>
                  <p className="font-body text-xs text-[#8B7B7B]">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional 2 on desktop */}
        <div className="hidden lg:grid lg:grid-cols-2 gap-6 mt-6">
          {testimonials.slice(3).map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.4 + i * 0.1, duration: 0.7 }}
              whileHover={{ y: -8 }}
              className={`bg-gradient-to-br ${t.color} rounded-3xl p-6 shadow-softer hover:shadow-soft transition-all duration-300 border border-white relative overflow-hidden`}
            >
              <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-white/30 -translate-y-1/2 translate-x-1/2" />
              <Quote className="w-8 h-8 text-rose-200 mb-4" />
              <StarRating count={t.stars} />
              <p className="font-body text-sm text-[#6B5B5B] leading-relaxed my-4 italic">"{t.text}"</p>
              <div className="flex items-center gap-3 pt-4 border-t border-white/60">
                <div className="w-10 h-10 rounded-full bg-white/60 flex items-center justify-center text-xl">{t.avatar}</div>
                <div>
                  <p className="font-display font-bold text-sm text-[#3D2C2C]">{t.name}</p>
                  <p className="font-body text-xs text-[#8B7B7B]">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Mobile carousel */}
        <div className="lg:hidden">
          <motion.div
            key={current}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            className={`bg-gradient-to-br ${testimonials[current].color} rounded-3xl p-6 shadow-softer border border-white`}
          >
            <Quote className="w-8 h-8 text-rose-200 mb-4" />
            <StarRating count={testimonials[current].stars} />
            <p className="font-body text-sm text-[#6B5B5B] leading-relaxed my-4 italic">"{testimonials[current].text}"</p>
            <div className="flex items-center gap-3 pt-4 border-t border-white/60">
              <div className="w-10 h-10 rounded-full bg-white/60 flex items-center justify-center text-xl">{testimonials[current].avatar}</div>
              <div>
                <p className="font-display font-bold text-sm text-[#3D2C2C]">{testimonials[current].name}</p>
                <p className="font-body text-xs text-[#8B7B7B]">{testimonials[current].role}</p>
              </div>
            </div>
          </motion.div>

          <div className="flex items-center justify-center gap-4 mt-6">
            <button onClick={prev} className="w-10 h-10 rounded-full glass shadow-softer flex items-center justify-center hover:shadow-soft transition-shadow">
              <ChevronLeft className="w-5 h-5 text-[#6B5B5B]" />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className={`rounded-full transition-all duration-300 ${i === current ? 'w-6 h-2.5 bg-rose-300' : 'w-2.5 h-2.5 bg-rose-100'}`}
                />
              ))}
            </div>
            <button onClick={next} className="w-10 h-10 rounded-full glass shadow-softer flex items-center justify-center hover:shadow-soft transition-shadow">
              <ChevronRight className="w-5 h-5 text-[#6B5B5B]" />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
