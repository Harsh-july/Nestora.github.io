import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { Shield, Heart, Salad, Brain, Activity, Sparkles, BookOpen, Sun } from 'lucide-react'

const features = [
  {
    icon: <Shield className="w-6 h-6" />,
    title: 'Safe Environment',
    desc: 'Child-safe infrastructure with 24/7 monitoring and verified, background-checked caregivers.',
    gradient: 'from-emerald-100 to-mint-light',
    iconColor: 'text-emerald-500',
    delay: 0,
  },
  {
    icon: <Heart className="w-6 h-6" />,
    title: 'Elderly Caregivers',
    desc: 'Experienced elders who bring warmth, patience, and a lifetime of wisdom to every interaction.',
    gradient: 'from-rose-100 to-pink-50',
    iconColor: 'text-rose-400',
    delay: 0.05,
  },
  {
    icon: <Salad className="w-6 h-6" />,
    title: 'Nutritious Meals',
    desc: 'Chef-crafted balanced meals designed for children and elderly alike, served with love.',
    gradient: 'from-amber-100 to-yellow-50',
    iconColor: 'text-amber-500',
    delay: 0.1,
  },
  {
    icon: <Brain className="w-6 h-6" />,
    title: 'Emotional Development',
    desc: 'Programs that nurture empathy, patience, and social intelligence in children.',
    gradient: 'from-violet-100 to-lavender-light',
    iconColor: 'text-violet-500',
    delay: 0.15,
  },
  {
    icon: <Activity className="w-6 h-6" />,
    title: 'Active Aging',
    desc: 'Gentle movement, games, and purposeful activities that keep elders energized and joyful.',
    gradient: 'from-blue-100 to-powder-light',
    iconColor: 'text-blue-400',
    delay: 0.2,
  },
  {
    icon: <Sparkles className="w-6 h-6" />,
    title: 'Hygienic Facilities',
    desc: 'Sanitized, beautifully designed spaces that feel like home — clean, warm, and welcoming.',
    gradient: 'from-teal-100 to-emerald-50',
    iconColor: 'text-teal-500',
    delay: 0.25,
  },
  {
    icon: <BookOpen className="w-6 h-6" />,
    title: 'Community Learning',
    desc: 'Cross-generational workshops where both children and elders discover new skills together.',
    gradient: 'from-orange-100 to-peach-light',
    iconColor: 'text-orange-400',
    delay: 0.3,
  },
  {
    icon: <Sun className="w-6 h-6" />,
    title: 'Purposeful Living',
    desc: 'Elders lead activities, share stories, and mentor children — finding deep meaning every day.',
    gradient: 'from-yellow-100 to-amber-50',
    iconColor: 'text-yellow-500',
    delay: 0.35,
  },
]

export default function WhyNestora() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="why" className="py-24 lg:py-32 bg-[#FFF8F0] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-violet-50 border border-violet-100 px-4 py-2 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-violet-400" />
            <span className="font-body text-sm text-violet-500 font-medium">Why Choose Us</span>
          </div>
          <h2 className="font-display font-extrabold text-4xl lg:text-5xl text-[#3D2C2C] mb-5">
            Everything Your Family{' '}
            <span className="text-gradient-cool">Deserves</span>
          </h2>
          <p className="font-body text-lg text-[#6B5B5B] max-w-2xl mx-auto">
            At Nestora, every detail is designed with one purpose — to create the most warm, safe, and enriching environment for every generation.
          </p>
        </motion.div>

        {/* Feature Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: f.delay }}
              whileHover={{ y: -8, boxShadow: '0 16px 48px rgba(0,0,0,0.08)' }}
              className="group bg-white rounded-3xl p-6 shadow-softer border border-transparent hover:border-white transition-all duration-400 cursor-pointer"
            >
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${f.gradient} flex items-center justify-center mb-4 ${f.iconColor} group-hover:scale-110 transition-transform duration-300`}>
                {f.icon}
              </div>
              <h3 className="font-display font-bold text-base text-[#3D2C2C] mb-2">{f.title}</h3>
              <p className="font-body text-sm text-[#8B7B7B] leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA strip */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6, duration: 0.7 }}
          className="mt-12 rounded-3xl bg-gradient-to-r from-rose-100 via-peach-light to-mint-light p-8 flex flex-col md:flex-row items-center justify-between gap-6"
        >
          <div>
            <h3 className="font-display font-bold text-xl text-[#3D2C2C] mb-1">Ready to experience Nestora?</h3>
            <p className="font-body text-sm text-[#6B5B5B]">Schedule a free visit and feel the warmth for yourself.</p>
          </div>
          <motion.a
            href="#contact"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
            className="flex-shrink-0 px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-300 to-orange-200 text-white font-display font-bold text-sm shadow-soft"
          >
            Book a Free Visit →
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}
