/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Nunito', 'sans-serif'],
        display: ['Poppins', 'sans-serif'],
        body: ['DM Sans', 'sans-serif'],
      },
      colors: {
        pink: {
          50: '#fff0f5',
          100: '#ffe0ec',
          200: '#ffc2d9',
          300: '#ff94b8',
          400: '#ff5c91',
          pastel: '#F9C6D3',
        },
        cream: '#FFF8F0',
        mint: {
          pastel: '#C8EDD9',
          light: '#E8F8EF',
        },
        lavender: {
          pastel: '#DDD6F3',
          light: '#EEE9FA',
        },
        peach: {
          pastel: '#FDDCBC',
          light: '#FEF0E0',
        },
        powder: {
          pastel: '#C5DFF8',
          light: '#E5F0FD',
        },
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'float-slow': 'float 9s ease-in-out infinite',
        'float-fast': 'float 4s ease-in-out infinite',
        'pulse-soft': 'pulseSoft 3s ease-in-out infinite',
        'blob': 'blob 7s infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        pulseSoft: {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0.6 },
        },
        blob: {
          '0%': { transform: 'translate(0px, 0px) scale(1)' },
          '33%': { transform: 'translate(30px, -50px) scale(1.1)' },
          '66%': { transform: 'translate(-20px, 20px) scale(0.9)' },
          '100%': { transform: 'translate(0px, 0px) scale(1)' },
        },
      },
      boxShadow: {
        'soft': '0 4px 24px rgba(0,0,0,0.06)',
        'softer': '0 2px 16px rgba(0,0,0,0.04)',
        'glow-pink': '0 0 40px rgba(249, 198, 211, 0.5)',
        'glow-mint': '0 0 40px rgba(200, 237, 217, 0.5)',
      },
    },
  },
  plugins: [],
}
